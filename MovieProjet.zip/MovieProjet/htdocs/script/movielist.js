fetch('http://127.0.0.1:8080/movies')
.then(function(response){
   return response.json();

})
.then(function(data){
    console.log(data[0].Series_Title);
})
.catch(function(err){
    console.log("Something went wrong!",err)
});